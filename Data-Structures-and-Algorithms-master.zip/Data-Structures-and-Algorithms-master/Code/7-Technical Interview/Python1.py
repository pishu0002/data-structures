# room_numbers = {
#     ['Freddie', 'Jen']: 403,
#     ['Ned', 'Keith']: 391,
#     ['Kristin', 'Jazzmyne']: 411,
#     ['Eugene', 'Zach']: 395
# }
tree ={1:{"left": 2, "right": None, "parent": 4

				}}
print(tree[1]["right"])